﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Windows.Forms;
using System.IO;

namespace DebugMap
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            bool startLoc = false;
            var WebC = new WebClient();
            WebC.DownloadFile(textBox2.Text, Application.StartupPath + "/csvFile.csv");
            WebC.Dispose();
            string ErrorLog = "";
            string csvFileText = File.ReadAllText(Application.StartupPath + "/csvFile.csv");
            ErrorLog = !csvFileText.Contains("#Width: ") ? "Width값이 없습니다."+Environment.NewLine : !csvFileText.Contains("#Height: ") ? "Height값이 없습니다."+Environment.NewLine : "";
            if (!csvFileText.Contains("#Width: ") || !csvFileText.Contains("#Height: ")) { startLoc = true; goto Exit; } 
            int width_ = int.Parse(csvFileText.Split(new string[] { "#Width: " }, StringSplitOptions.None)[1].Split(',')[0]);
            int height_ = int.Parse(csvFileText.Split(new string[] { "#Height: " }, StringSplitOptions.None)[1].Split(',')[0]);
            string[] AloneTile = { "Q", "W", "E", "R", "T", "A", "X", "K" };
            string[] AllAloneTile = { "Q", "W", "E", "R", "T", "A", "X", "K", "Y", "U" };
            string[] WithTile = { "M0", "M1", "M2", "M3", "M4", "M5", "M6", "M7", "M8", "M9", "M10", "P1", "D", "P", "O", "S", "L" };
            string[] SplitNewline = csvFileText.Split('\n');
            csvFileText = "";
            for (int i = 0; i <= height_ - 1; i++)
            {
                for (int j = 0; j <= width_ - 1; j++)
                {
                    string SplitCom = SplitNewline[i].Split(',')[j];
                    if (SplitCom.Contains("//")) continue;
                    if (SplitCom.Contains('_'))
                    {
                        string[] _SplitText = SplitCom.Split('_');
                        startLoc = (_SplitText[1] == "S" || _SplitText[0] == "S") ? true : (startLoc) ? true : false;
                        foreach (string With in WithTile)
                        {
                            foreach (string Alone in AloneTile)
                            {
                                if (_SplitText[0] == With && _SplitText[1] == Alone ||
                                    _SplitText[1] == With && _SplitText[0] == Alone)
                                {
                                    goto Exit;
                                }
                            }
                            foreach (string With_ in WithTile)
                            {
                                if (_SplitText[0] == With && _SplitText[1] == With_ ||
                                    _SplitText[1] == With && _SplitText[0] == With_)
                                {
                                    goto Exit;
                                }
                                else if (With == "L" && With_ == "L")
                                {
                                    ErrorLog += i + 1 + "," + j + 1 + ": 없는 중복타일 입니다." + Environment.NewLine;
                                    goto Exit;
                                }
                            }
                        }
                    }
                    else
                    {
                        foreach (string Alone in AllAloneTile)
                        {
                            if (SplitCom == Alone)
                            {
                                break;
                            }
                            else if (Alone == "K")
                            {
                                ErrorLog += (i + 1) + "," + (j + 1) + ": 없는 타일 입니다." + Environment.NewLine;
                            }
                            else if (char.IsLower(char.Parse(Alone)))
                            {
                                ErrorLog += (i + 1) + "," + (j + 1) + ": 타일은 대문자여야합니다." + Environment.NewLine;
                            }
                        }
                    }
                }
            }
            Exit:
            textBox1.Text += (ErrorLog == "") ? "문제 없는 csv 파일" : ErrorLog + (startLoc ? "" : "시작지점이 없습니다." + Environment.NewLine);
        }
    }
}