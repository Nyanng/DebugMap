﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Windows.Forms;
using System.IO;

namespace DebugMap
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string[] errorArr = new string[4];
            listView1.Items.Clear();
            bool startLoc = false;
            bool endLoc = false;
            var WebC = new WebClient();
            WebC.DownloadFile(textBox2.Text, Application.StartupPath + "/csvFile.csv");
            WebC.Dispose();
            string ErrorLog = "";
            string csvFileText = File.ReadAllText(Application.StartupPath + "/csvFile.csv");
            if (!csvFileText.Contains("#Width: ")) ErrorLog += "Error : Width값이 없습니다." + Environment.NewLine; if(!csvFileText.Contains("#Height: ")) ErrorLog += "Error : Height값이 없습니다." + Environment.NewLine;
            if (!csvFileText.Contains("#Width: ") || !csvFileText.Contains("#Height: ")) { startLoc = true; endLoc = true; goto Exit; } 
            int width_ = int.Parse(csvFileText.Split(new string[] { "#Width: " }, StringSplitOptions.None)[1].Split(',')[0]);
            int height_ = int.Parse(csvFileText.Split(new string[] { "#Height: " }, StringSplitOptions.None)[1].Split(',')[0]);
            string[] AloneTile = { "Q", "W", "E", "R", "T", "A", "X", "K" };
            string[] AllAloneTile = { "Q", "W", "E", "R", "T", "A", "X", "K", "Y", "U" };
            string[] WithTile = { "M0", "M1", "M2", "M3", "M4", "M5", "M6", "M7", "M8", "M9", "M10", "P1", "D", "P", "O", "S", "L" };
            string[] SplitNewline = csvFileText.Split('\n');
            csvFileText = "";
            for (int i = 0; i <= height_ - 1; i++)
            {
                for (int j = 0; j <= width_ - 1; j++)
                {                    
                    string SplitCom = SplitNewline[i].Split(',')[j];
                    if (SplitCom.Contains("//") && SplitCom.Trim().Substring(0, 2) == "//") continue;
                    if (SplitCom.Contains('_'))
                    {
                        string[] _SplitText = SplitCom.Split('_');
                        startLoc = (_SplitText[1] == "S" || _SplitText[0] == "S") ? true : (startLoc) ? true : false;
                        endLoc = (_SplitText[1] == "L" || _SplitText[0] == "L") ? true : (endLoc) ? true : false;
                        foreach (string With in WithTile)
                        {
                            foreach (string Alone in AloneTile)
                            {
                                if (_SplitText[0] == With && _SplitText[1] == Alone ||
                                    _SplitText[1] == With && _SplitText[0] == Alone)
                                {
                                    goto For_;
                                }
                            }
                            foreach (string With_ in WithTile)
                            {
                                if (_SplitText[0] == With && _SplitText[1] == With_ ||
                                    _SplitText[1] == With && _SplitText[0] == With_)
                                {
                                    goto For_;
                                }
                                else if (With == "L" && With_ == "L")
                                {
                                    errorArr[0] = "Error";
                                    errorArr[1] = (i + 1) + "," + (j + 1);
                                    errorArr[2] = "옳지않은 중복타일 입니다.";
                                    errorArr[3] = SplitCom;
                                    listView1.Items.Add(new ListViewItem(errorArr));
                                    goto For_;
                                }
                            }
                        }
                    }
                    else
                    {
                        startLoc = (SplitCom == "S") ? true : (startLoc) ? true : false;
                        endLoc = (SplitCom == "L") ? true : (endLoc) ? true : false;
                        foreach (string With in WithTile)
                        {
                            if (SplitCom == With)
                            {
                                errorArr[0] = "Error";
                                errorArr[1] = (i + 1) + "," + (j + 1);
                                errorArr[2] = "이 타일은 배경타일을 필요로 합니다.";
                                errorArr[3] = SplitCom;
                                listView1.Items.Add(new ListViewItem(errorArr));
                                goto For_;
                            }
                        }
                        foreach (string Alone in AllAloneTile)
                        {
                            if (SplitCom == Alone)
                            {
                                goto For_;
                            }
                            else if (SplitCom.Equals(Alone , StringComparison.OrdinalIgnoreCase))
                            {
                                errorArr[0] = "Error";
                                errorArr[1] = (i + 1) + "," + (j + 1);
                                errorArr[2] = "이 타일은 대문자여야합니다.";
                                errorArr[3] = SplitCom;
                                listView1.Items.Add(new ListViewItem(errorArr));
                                goto For_;
                            }
                            else if (Alone == "K")
                            {
                                errorArr[0] = "Error";
                                errorArr[1] = (i + 1) + "," + (j + 1);
                                errorArr[2] = "존재하지 않는 타일 입니다.";
                                errorArr[3] = SplitCom;
                                listView1.Items.Add(new ListViewItem(errorArr));
                                goto For_;
                            }
                        }
                    }
                    For_:;
                }
            }
            Exit:
            if (!startLoc)
            { 
                errorArr[0] = "Error";
                errorArr[1] = "";
                errorArr[2] = "시작타일이 존재하지 않습니다.";
                errorArr[3] = "";
                listView1.Items.Add(new ListViewItem(errorArr));
            }
            if (!endLoc)
            {
                errorArr[0] = "Warning";
                errorArr[1] = "";
                errorArr[2] = "종료타일이 존재하지 않습니다.";
                errorArr[3] = "";
                listView1.Items.Add(new ListViewItem(errorArr));
            }
            if (errorArr[0] == "")
            {
                errorArr[0] = "Success";
                errorArr[1] = "";
                errorArr[2] = "정상적인 CSV 파일입니다.";
                errorArr[3] = "";
                listView1.Items.Add(new ListViewItem(errorArr));
            }
            File.Delete(Application.StartupPath + "/csvFile.csv");
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            listView1.FullRowSelect = true;
            listView1.GridLines = true;
        }
    }
}